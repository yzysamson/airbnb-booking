let ROOMS=[];
let BOOKINGS=[];
let DAYS=[];
let FILTER=new Set();
let selectState=null;
let editing=null;
