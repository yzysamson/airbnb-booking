const app=document.getElementById('app');
const legend=document.getElementById('legend');
const summary=document.getElementById('summary');
const modal=document.getElementById('modal');

const saveBtn=document.getElementById('saveBtn');
const deleteBtn=document.getElementById('deleteBtn');

const roomInput=document.getElementById('roomInput');
const checkinInput=document.getElementById('checkinInput');
const checkoutInput=document.getElementById('checkoutInput');
const sourceInput=document.getElementById('sourceInput');
const priceInput=document.getElementById('priceInput');
const remarkInput=document.getElementById('remarkInput');
const modalTitle=document.getElementById('modalTitle');
const monthPicker=document.getElementById('monthPicker');
